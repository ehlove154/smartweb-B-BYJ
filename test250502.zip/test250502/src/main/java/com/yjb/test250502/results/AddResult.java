package com.yjb.test250502.results;

public enum AddResult {
    FAILURE,
    FAILURE_DUPLICATE_ID,
    SUCCESS
}
