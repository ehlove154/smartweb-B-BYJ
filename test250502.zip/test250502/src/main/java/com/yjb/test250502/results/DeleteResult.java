package com.yjb.test250502.results;

public enum DeleteResult {
    FAILURE,
    SUCCESS
}
