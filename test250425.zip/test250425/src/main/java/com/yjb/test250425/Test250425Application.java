package com.yjb.test250425;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test250425Application {

    public static void main(String[] args) {
        SpringApplication.run(Test250425Application.class, args);
    }

}
