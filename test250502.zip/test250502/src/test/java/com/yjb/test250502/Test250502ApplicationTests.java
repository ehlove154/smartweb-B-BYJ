package com.yjb.test250502;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test250502ApplicationTests {

    @Test
    void contextLoads() {
    }

}
