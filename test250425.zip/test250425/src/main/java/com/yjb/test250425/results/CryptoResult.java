package com.yjb.test250425.results;

public enum CryptoResult {
    FAILURE,
    SUCCESS
}
