package com.yjb.test250425;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test250425ApplicationTests {

    @Test
    void contextLoads() {
    }

}
