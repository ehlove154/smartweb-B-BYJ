package com.yjb.test250502;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test250502Application {

    public static void main(String[] args) {
        SpringApplication.run(Test250502Application.class, args);
    }

}
